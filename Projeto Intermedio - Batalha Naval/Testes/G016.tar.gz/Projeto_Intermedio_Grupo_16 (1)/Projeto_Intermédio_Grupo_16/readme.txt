ATENÇÃO: 
Notámos que no script que nos forneceu, a restrição das linhas 56-59 que basicamente impede 
o jogador de selecionar os modos de disparo nos modos de jogo 0 e 1, provocava um conflito, 
fazendo o script entrar em loop. Contudo no enunciado é referida a invalidez da invocação 
do programa com um modo de disparo e o modo de jogo 0 e 1 em simultâneo.

PROJETO.C:
Este programa é um programa adicional que decidimos submeter visto que o professor sugeriu
que poderia ser considerado como uma mais-valia. A funcionalidade é a mesma contudo não é
necessário introduzir os comandos com '-' para chamar os modos de jogo. O próprio programa
pergunta ao utilizador que modos quer. Além do mais adicionámos alguns gráficos interessantes 
e um tabuleiro mais robusto! Convidamos o professor a jogar. ;)